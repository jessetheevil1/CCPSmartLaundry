package ccpsmartlaundry;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.*;

public class Dryer {
    private Semaphore available;
    private boolean[] dryerInUse;
    private Stats stats;
    private final Object lock = new Object();
    private AtomicInteger waitingQueue = new AtomicInteger(0);
    
    public Dryer(Stats stats) {
        this.stats = stats;
        this.available = new Semaphore(4, true);
        this.dryerInUse = new boolean[4];
        Arrays.fill(dryerInUse, false);
    }
    
    public int acquireDryer(int customerID) throws InterruptedException {
        waitingQueue.incrementAndGet();
        System.out.printf("[%.2f] Customer-%d waiting for dryer\n",
            CCPSmartLaundry.getCurrentTime(), customerID);
        
        available.acquire();
        waitingQueue.decrementAndGet();
        
        int dryerID;
        synchronized (lock) {
            dryerID = getAvailableDryer();
        }
        
        int inUse = 4 - available.availablePermits();
        stats.updateDryerUsage(inUse);
        
        System.out.printf("[%.2f] Customer-%d acquired Dryer-%d (%d dryers available)\n",
            CCPSmartLaundry.getCurrentTime(), customerID, dryerID, available.availablePermits());
        
        return dryerID;
    }
    
    public int tryAcquireDryer() {
        if (available.tryAcquire()) {
            int dryerID;
            synchronized (lock) {
                dryerID = getAvailableDryer();
            }
            if (dryerID != -1) {
                int inUse = 4 - available.availablePermits();
                stats.updateDryerUsage(inUse);
                return dryerID;
            } else {
                available.release();
            }
        }
        return -1;
    }
    
    public void releaseDryer(int dryerID) {
        synchronized (lock) {
            dryerInUse[dryerID] = false;
        }
        
        available.release();
        
        int inUse = 4 - available.availablePermits();
        stats.updateDryerUsage(inUse);
        
        System.out.printf("[%.2f] Customer released Dryer-%d (%d dryers available)\n",
            CCPSmartLaundry.getCurrentTime(), dryerID, available.availablePermits());
    }
    
    private int getAvailableDryer() {
        for (int i = 0; i < dryerInUse.length; i++) {
            if (!dryerInUse[i]) {
                dryerInUse[i] = true;
                return i;
            }
        }
        return -1;
    }
    
    public boolean[] getDryerInUse() {
        synchronized (lock) {
            return dryerInUse.clone();
        }
    }
    
    public int getWaitingQueue() {
        return waitingQueue.get();
    }
    
    public void incrementWaiting() {
        waitingQueue.incrementAndGet();
    }
    
    public void decrementWaiting() {
        waitingQueue.decrementAndGet();
    }
    
    public int getTotalCount() {
        return 4;
    }
}