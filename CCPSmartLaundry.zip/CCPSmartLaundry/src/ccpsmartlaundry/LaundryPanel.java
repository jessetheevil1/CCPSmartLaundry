package ccpsmartlaundry;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.concurrent.locks.*;
import java.util.concurrent.atomic.*;

public class LaundryPanel extends Panel implements Runnable, ActionListener {
    
    private Button startButton;
    private Button pauseButton;
    private Button resetButton;
    private Button clearLogButton;
    private Button normalButton;
    private Button congestedButton;
    private TextArea washerArea, dryerArea, kioskArea, foldingArea, logArea;
    private Label statsLabel, congestionLabel, congestionIndicator, scenarioLabel;
    private Label titleStatsLabel;
    
    private Washer washerRef;
    private Dryer dryerRef;
    private PaymentKiosk kioskRef;
    private FoldingStation stationRef;
    private Stats stats;
    private Laundromat laundromat;
    private Thread simThread;
    private volatile boolean running = false;
    private volatile boolean paused = false;
    
    private AtomicInteger customersServed;
    private AtomicInteger activeCustomers;
    
    private ReentrantLock congestionLock;
    
    private volatile boolean simRunning = true;
    private boolean congestionForced = false;
    private int currentScenario = CCPSmartLaundry.SCENARIO_NORMAL;
    
    private SimController controller;
    
    private Label washerQueueLabel, dryerQueueLabel, kioskQueueLabel, foldingQueueLabel;
    
    public LaundryPanel() {
        customersServed = new AtomicInteger(0);
        activeCustomers = new AtomicInteger(0);
        congestionLock = new ReentrantLock();
        
        setupUI();
        startRefreshTimer();
    }

    private void setupUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(0, 153, 153));
        
        add(createNorthPanel(), BorderLayout.NORTH);
        add(createCenterPanel(), BorderLayout.CENTER);
        add(createSouthPanel(), BorderLayout.SOUTH);
    }

    private Panel createNorthPanel() {
        Panel panel = new Panel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(50, 50, 80));
        
        Label titleLabel = new Label("CCP Smart Laundry Simulation", Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBackground(new Color(50, 50, 80));
        
        Panel titleStatsPanel = new Panel();
        titleStatsPanel.setLayout(new BorderLayout());
        titleStatsPanel.setBackground(new Color(50, 50, 80));
        
        titleStatsLabel = new Label("Customers: 0 | Completed: 0 | Left: 0 | Active: 0 | Congestion: 0", Label.CENTER);
        titleStatsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        titleStatsLabel.setForeground(Color.CYAN);
        titleStatsLabel.setBackground(new Color(50, 50, 80));
        titleStatsLabel.setPreferredSize(new Dimension(800, 25));
        titleStatsPanel.add(titleStatsLabel, BorderLayout.CENTER);
        
        scenarioLabel = new Label("SCENARIO: NORMAL", Label.CENTER);
        scenarioLabel.setFont(new Font("Arial", Font.BOLD, 12));
        scenarioLabel.setForeground(Color.CYAN);
        scenarioLabel.setBackground(new Color(50, 50, 80));
        
        statsLabel = new Label("Customers Served: 0 | Active: 0 | Completed: 0", Label.CENTER);
        statsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        statsLabel.setForeground(Color.YELLOW);
        statsLabel.setBackground(new Color(50, 50, 80));
        statsLabel.setPreferredSize(new Dimension(500, 25));
        
        congestionLabel = new Label("", Label.CENTER);
        congestionLabel.setFont(new Font("Arial", Font.BOLD, 12));
        congestionLabel.setForeground(Color.RED);
        congestionLabel.setBackground(Color.YELLOW);
        congestionLabel.setVisible(false);
        congestionLabel.setPreferredSize(new Dimension(600, 25));
        
        congestionIndicator = new Label("", Label.CENTER);
        congestionIndicator.setFont(new Font("Arial", Font.BOLD, 14));
        congestionIndicator.setForeground(Color.WHITE);
        congestionIndicator.setBackground(new Color(0, 153, 153));
        congestionIndicator.setVisible(false);
        
        Panel topPanel = new Panel();
        topPanel.setLayout(new BorderLayout());
        topPanel.setBackground(new Color(50, 50, 80));
        topPanel.add(titleLabel, BorderLayout.NORTH);
        topPanel.add(titleStatsPanel, BorderLayout.CENTER);
        topPanel.add(statsLabel, BorderLayout.SOUTH);
        
        Panel bottomPanel = new Panel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.setBackground(new Color(50, 50, 80));
        bottomPanel.add(congestionLabel, BorderLayout.NORTH);
        bottomPanel.add(congestionIndicator, BorderLayout.SOUTH);
        
        panel.add(topPanel, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        return panel;
    }

    private Panel createCenterPanel() {
        Panel centerPanel = new Panel();
        centerPanel.setLayout(new GridLayout(2, 2, 15, 15));
        centerPanel.setBackground(new Color(0, 153, 153));
        
        washerArea = createResourceDisplay("WASHING MACHINES (6)");
        dryerArea = createResourceDisplay("DRYERS (4)");
        kioskArea = createResourceDisplay("PAYMENT KIOSKS (2)");
        foldingArea = createResourceDisplay("FOLDING STATIONS (2) - Additional");
        
        centerPanel.add(createResourceContainer("WASHING MACHINES", washerArea, new Color(70, 130, 200)));
        centerPanel.add(createResourceContainer("DRYERS", dryerArea, new Color(255, 140, 0)));
        centerPanel.add(createResourceContainer("PAYMENT KIOSKS", kioskArea, new Color(34, 139, 34)));
        centerPanel.add(createResourceContainer("FOLDING STATIONS", foldingArea, new Color(128, 0, 128)));
        
        return centerPanel;
    }

    private TextArea createResourceDisplay(String title) {
        TextArea textArea = new TextArea(10, 25);
        textArea.setEditable(false);
        textArea.setBackground(Color.WHITE);
        textArea.setForeground(Color.BLACK);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        return textArea;
    }

    private Panel createResourceContainer(String title, TextArea textArea, Color themeColor) {
        Panel container = new Panel();
        container.setLayout(new BorderLayout());
        container.setBackground(themeColor);

        Label titleLabel = new Label(title, Label.CENTER);
        titleLabel.setBackground(themeColor);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 12));

        Panel contentPanel = new Panel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);
        
        Panel textWrapper = new Panel();
        textWrapper.setLayout(new BorderLayout());
        textWrapper.setBackground(Color.WHITE);
        
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setBackground(Color.WHITE);
        scrollPane.add(textArea);
        scrollPane.setPreferredSize(new Dimension(280, 150));
        
        textWrapper.add(scrollPane, BorderLayout.CENTER);
        
        Label queueLabel = new Label("Queue: 0", Label.CENTER);
        queueLabel.setFont(new Font("Arial", Font.BOLD, 11));
        queueLabel.setForeground(Color.BLUE);
        queueLabel.setBackground(Color.WHITE);
        
        Panel queuePanel = new Panel();
        queuePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        queuePanel.setBackground(Color.WHITE);
        queuePanel.add(queueLabel);
        
        contentPanel.add(textWrapper, BorderLayout.CENTER);
        contentPanel.add(queuePanel, BorderLayout.SOUTH);

        container.add(titleLabel, BorderLayout.NORTH);
        container.add(contentPanel, BorderLayout.CENTER);
        
        if (title.contains("WASHING")) {
            washerQueueLabel = queueLabel;
        } else if (title.contains("DRYERS")) {
            dryerQueueLabel = queueLabel;
        } else if (title.contains("PAYMENT")) {
            kioskQueueLabel = queueLabel;
        } else if (title.contains("FOLDING")) {
            foldingQueueLabel = queueLabel;
        }

        return container;
    }

    private Panel createSouthPanel() {
        Panel southPanel = new Panel();
        southPanel.setLayout(new BorderLayout());
        southPanel.setBackground(new Color(0, 153, 153));
        
        southPanel.add(createControlPanel(), BorderLayout.NORTH);
        southPanel.add(createLegendPanel(), BorderLayout.CENTER);
        southPanel.add(createLogPanel(), BorderLayout.SOUTH);
        
        return southPanel;
    }

    private Panel createControlPanel() {
        Panel controlPanel = new Panel();
        controlPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        controlPanel.setBackground(new Color(0, 153, 153));
        
        normalButton = new Button("Normal");
        congestedButton = new Button("Congested");
        normalButton.setBackground(Color.GREEN);
        congestedButton.setBackground(Color.LIGHT_GRAY);
        
        normalButton.addActionListener(this);
        congestedButton.addActionListener(this);
        
        startButton = new Button("Start");
        pauseButton = new Button("Pause");
        resetButton = new Button("Reset");
        clearLogButton = new Button("Clear Log");
        
        startButton.setBackground(Color.GREEN);
        pauseButton.setBackground(Color.ORANGE);
        resetButton.setBackground(Color.LIGHT_GRAY);
        clearLogButton.setBackground(Color.LIGHT_GRAY);
        
        startButton.addActionListener(this);
        pauseButton.addActionListener(this);
        resetButton.addActionListener(this);
        clearLogButton.addActionListener(this);
        
        controlPanel.add(new Label("Scenario:"));
        controlPanel.add(normalButton);
        controlPanel.add(congestedButton);
        controlPanel.add(new Label("|"));
        controlPanel.add(startButton);
        controlPanel.add(pauseButton);
        controlPanel.add(resetButton);
        controlPanel.add(clearLogButton);
        
        return controlPanel;
    }

    private Panel createLegendPanel() {
        Panel legendPanel = new Panel();
        legendPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        legendPanel.setBackground(Color.LIGHT_GRAY);
        legendPanel.setFont(new Font("Arial", Font.PLAIN, 9));
        
        legendPanel.add(createLegendItem("□ FREE", Color.LIGHT_GRAY));
        legendPanel.add(createLegendItem("█ WASHER", new Color(70, 130, 200)));
        legendPanel.add(createLegendItem("█ DRYER", new Color(255, 140, 0)));
        legendPanel.add(createLegendItem("█ KIOSK", new Color(34, 139, 34)));
        legendPanel.add(createLegendItem("█ FOLDING", new Color(128, 0, 128)));
        legendPanel.add(createLegendItem("⚠ CONGESTION", Color.RED));
        legendPanel.add(createLegendItem("📊 QUEUE", Color.BLUE));
        
        return legendPanel;
    }

    private Panel createLegendItem(String text, Color color) {
        Panel panel = new Panel();
        panel.setLayout(new FlowLayout(FlowLayout.LEFT, 3, 0));
        panel.setBackground(Color.LIGHT_GRAY);
        
        Label colorBox = new Label("   ");
        colorBox.setBackground(color);
        colorBox.setPreferredSize(new Dimension(15, 15));
        
        Label textLabel = new Label(text);
        textLabel.setBackground(Color.LIGHT_GRAY);
        textLabel.setFont(new Font("Arial", Font.PLAIN, 9));
        
        panel.add(colorBox);
        panel.add(textLabel);
        
        return panel;
    }

    private Panel createLogPanel() {
        Panel logContainer = new Panel();
        logContainer.setLayout(new BorderLayout());
        logContainer.setBackground(Color.BLACK);
        
        logArea = new TextArea(6, 80);
        logArea.setEditable(false);
        logArea.setBackground(Color.BLACK);
        logArea.setForeground(Color.GREEN);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 10));
        
        logContainer.add(logArea, BorderLayout.CENTER);
        
        return logContainer;
    }

    public Stats getStats() {
        return stats;
    }
    
    public PaymentKiosk getKioskRef() {
        return kioskRef;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            startSim();
        } else if (e.getSource() == pauseButton) {
            pauseSimulation();
        } else if (e.getSource() == resetButton) {
            resetSimulation();
        } else if (e.getSource() == clearLogButton) {
            clearLog();
        } else if (e.getSource() == normalButton) {
            setScenario(CCPSmartLaundry.SCENARIO_NORMAL);
        } else if (e.getSource() == congestedButton) {
            setScenario(CCPSmartLaundry.SCENARIO_CONGESTED);
        }
    }
    
    public void setScenario(int scenario) {
        if (controller != null && controller.isControllerRunning()) {
            controller.stopController();
            try {
                controller.join(1000);
            } catch (InterruptedException ex) {
            }
        }
        
        currentScenario = scenario;
        congestionForced = false;
        
        if (scenario == CCPSmartLaundry.SCENARIO_NORMAL) {
            scenarioLabel.setText("SCENARIO: NORMAL");
            normalButton.setBackground(Color.GREEN);
            congestedButton.setBackground(Color.LIGHT_GRAY);
            logMessage("=== NORMAL SCENARIO SELECTED ===");
        } else {
            scenarioLabel.setText("SCENARIO: CONGESTED");
            congestedButton.setBackground(Color.ORANGE);
            normalButton.setBackground(Color.LIGHT_GRAY);
            logMessage("=== CONGESTED SCENARIO SELECTED ===");
        }
    }
    
    public void startSim() {
        if (simThread == null || !simThread.isAlive()) {
            simRunning = true;
            running = true;
            paused = false;
            
            simThread = new Thread(this);
            simThread.start();
            
            controller = new SimController(this, currentScenario);
            controller.start();
            
            startButton.setEnabled(false);
            pauseButton.setEnabled(true);
            
            logMessage("=== SIMULATION STARTED ===");
        }
    }
    
    public void pauseSimulation() {
        paused = true;
        if (controller != null) {
            controller.stopController();
        }
        pauseButton.setEnabled(false);
        startButton.setEnabled(true);
        logMessage("=== SIMULATION PAUSED ===");
    }

    public void resetSimulation() {
        running = false;
        paused = false;
        simRunning = false;
        
        if (controller != null) {
            controller.stopController();
            controller = null;
        }
        
        if (simThread != null) {
            simThread.interrupt();
            simThread = null;
        }
        
        if (statsLabel != null) {
            statsLabel.setText("Customers Served: 0 | Active: 0 | Completed: 0");
        }
        if (titleStatsLabel != null) {
            titleStatsLabel.setText("Customers: 0 | Completed: 0 | Left: 0 | Active: 0 | Congestion: 0");
        }
        if (congestionLabel != null) {
            congestionLabel.setVisible(false);
        }
        if (congestionIndicator != null) {
            congestionIndicator.setVisible(false);
        }
        setBackground(new Color(0, 153, 153));
        
        if (washerArea != null) {
            washerArea.setText("");
        }
        if (dryerArea != null) {
            dryerArea.setText("");
        }
        if (kioskArea != null) {
            kioskArea.setText("");
        }
        if (foldingArea != null) {
            foldingArea.setText("");
        }
        
        if (washerQueueLabel != null) {
            washerQueueLabel.setText("Queue: 0");
        }
        if (dryerQueueLabel != null) {
            dryerQueueLabel.setText("Queue: 0");
        }
        if (kioskQueueLabel != null) {
            kioskQueueLabel.setText("Queue: 0");
        }
        if (foldingQueueLabel != null) {
            foldingQueueLabel.setText("Queue: 0");
        }
        
        stats = new Stats();
        
        logMessage("=== SIMULATION RESET ===");
        
        startButton.setEnabled(true);
        pauseButton.setEnabled(true);
    }

    public void clearLog() {
        if (logArea != null) {
            logArea.setText("");
            logMessage("Log cleared.");
        }
    }

    @Override
    public void run() {
        try {
            CCPSmartLaundry.SIM_START_TIME = System.currentTimeMillis();

            stats = new Stats();
            laundromat = new Laundromat(stats, this);

            Thread[] customers = new Thread[50];
            Random random = new Random();

            logMessage("Simulation starting with 50 customers...");
            logMessage("Configuration: 6 Washers, 4 Dryers, 2 Kiosks, 2 Folding Stations");
            logMessage("10% failure chance for washers and payment kiosks");
            logMessage("Congestion when 30+ customers wait for payment");
            logMessage("Customer patience: 20 seconds");
            logMessage("Wash: 4-6s, Dry: 3-5s, Payment: 1-2s, Fold: 1.5s");

            for (int i = 0; i < 50 && running; i++) {
                while (paused && running) {
                    Thread.sleep(100);
                }

                int customerID = i + 1;
                Customer customer = new Customer(customerID, laundromat, stats, this);
                customers[i] = new Thread(customer, "Customer-" + customerID);
                customers[i].start();

                int arrivalDelay = random.nextInt(501);
                Thread.sleep(arrivalDelay);
            }

            for (Thread customer : customers) {
                if (customer != null) {
                    customer.join();
                }
            }

            if (running) {
                stats.printReport();
                logMessage("=== SIMULATION COMPLETED ===");
            }

            startButton.setEnabled(true);
            pauseButton.setEnabled(false);

        } catch (InterruptedException e) {
            logMessage("Simulation interrupted.");
        }
    }

    public void setResources(Washer washer, Dryer dryer, PaymentKiosk kiosk, FoldingStation station) {
        this.washerRef = washer;
        this.dryerRef = dryer;
        this.kioskRef = kiosk;
        this.stationRef = station;
    }

    public void updateWasherDisplay() {
        if (washerArea == null || washerRef == null) return;
        
        StringBuilder sb = new StringBuilder();
        boolean[] washerInUse = washerRef.getWasherInUse();
        
        int inUseCount = 0;
        int freeCount = 0;
        for (int i = 0; i < 6; i++) {
            String status = (washerInUse[i]) ? "█ IN USE" : "□ FREE";
            sb.append(String.format("Washer %d: %s\n", (i + 1), status));
            if (washerInUse[i]) inUseCount++;
            else freeCount++;
        }
        sb.append(String.format("\nAvailable: %d | In Use: %d", freeCount, inUseCount));
        
        washerArea.setText(sb.toString());
        
        if (washerQueueLabel != null) {
            int queue = washerRef.getWaitingQueue();
            washerQueueLabel.setText("Queue: " + (queue < 0 ? 0 : queue));
        }
    }

    public void updateDryerDisplay() {
        if (dryerArea == null || dryerRef == null) return;
        
        StringBuilder sb = new StringBuilder();
        boolean[] dryerInUse = dryerRef.getDryerInUse();
        
        int inUseCount = 0;
        int freeCount = 0;
        for (int i = 0; i < 4; i++) {
            String status = (dryerInUse[i]) ? "█ IN USE" : "□ FREE";
            sb.append(String.format("Dryer %d: %s\n", (i + 1), status));
            if (dryerInUse[i]) inUseCount++;
            else freeCount++;
        }
        sb.append(String.format("\nAvailable: %d | In Use: %d", freeCount, inUseCount));
        
        dryerArea.setText(sb.toString());
        
        if (dryerQueueLabel != null) {
            int queue = dryerRef.getWaitingQueue();
            dryerQueueLabel.setText("Queue: " + (queue < 0 ? 0 : queue));
        }
    }

    public void updateKioskDisplay() {
        if (kioskArea == null || kioskRef == null) return;

        StringBuilder sb = new StringBuilder();
        boolean[] kioskInUse = kioskRef.getKioskInUse();

        int inUseCount = 0;
        int freeCount = 0;
        for (int i = 0; i < 2; i++) {
            String status = (kioskInUse[i]) ? "█ IN USE" : "□ FREE";
            sb.append(String.format("Kiosk %d: %s\n", (i + 1), status));
            if (kioskInUse[i]) inUseCount++;
            else freeCount++;
        }
        
        int waitingCount = kioskRef.getWaitingCount();
        if (waitingCount < 0) waitingCount = 0;
        
        sb.append(String.format("\nAvailable: %d | In Use: %d", freeCount, inUseCount));
        sb.append(String.format("\nQueue: %d waiting", waitingCount));
        if (kioskRef.isCongestedMode()) {
            sb.append("\n⚠⚠⚠ CONGESTION MODE ACTIVE! ⚠⚠⚠");
            sb.append("\n🔴 BOTH KIOSKS ARE BROKEN!");
            sb.append(String.format("\n📊 %d customers waiting in queue!", waitingCount));
        }

        kioskArea.setText(sb.toString());

        if (kioskQueueLabel != null) {
            kioskQueueLabel.setText("Queue: " + waitingCount);
        }
    }

    public void updateFoldingDisplay() {
        if (foldingArea == null || stationRef == null) return;
        
        StringBuilder sb = new StringBuilder();
        boolean[] stationInUse = stationRef.getStationInUse();
        
        int inUseCount = 0;
        int freeCount = 0;
        for (int i = 0; i < 2; i++) {
            String status = (stationInUse[i]) ? "█ IN USE" : "□ FREE";
            sb.append(String.format("Station %d: %s\n", (i + 1), status));
            if (stationInUse[i]) inUseCount++;
            else freeCount++;
        }
        sb.append(String.format("\nAvailable: %d | In Use: %d", freeCount, inUseCount));
        
        foldingArea.setText(sb.toString());
        
        if (foldingQueueLabel != null) {
            int queue = stationRef.getWaitingQueue();
            foldingQueueLabel.setText("Queue: " + (queue < 0 ? 0 : queue));
        }
    }

    public void logMessage(String message) {
        if (logArea != null) {
            logArea.append(message + "\n");
        }
        System.out.println(message);
    }
    
    public void updateCustomerCount(int active) {
        if (stats == null) return;
        
        int completed = stats.getCustomersCompleted();
        int left = stats.getCustomersLeft();
        int served = completed + left;
        int congestion = stats.getCongestionEvents();
        
        customersServed.set(served);
        activeCustomers.set(active);
        
        if (statsLabel != null) {
            statsLabel.setText(String.format("Customers Served: %d | Active: %d | Completed: %d",
                served, active, completed));
        }
        
        if (titleStatsLabel != null) {
            titleStatsLabel.setText(String.format("Customers: %d | Completed: %d | Left: %d | Active: %d | Congestion: %d",
                served, completed, left, active, congestion));
        }
    }
 
    public void showCongestionAlert(boolean show) {
        if (congestionLabel != null) {
            congestionLabel.setVisible(show);
            if (show) {
                congestionLabel.setText("CONGESTION: BOTH PAYMENT MACHINES FAILED! OWNER CALLED!");
            }
        }
    }
    
    public void showCongestionIndicator(boolean show) {
        if (congestionIndicator != null) {
            congestionIndicator.setVisible(show);
            if (show) {
                congestionIndicator.setBackground(Color.RED);
                congestionIndicator.setText("⚠ CONGESTION ACTIVE ⚠");
                setBackground(Color.RED);
            } else {
                congestionIndicator.setBackground(new Color(0, 153, 153));
                setBackground(new Color(0, 153, 153));
            }
        }
    }
    
    public boolean isRunning() {
        return simRunning && (simThread == null || !simThread.isInterrupted());
    }

    public void stopSim() {
        simRunning = false;
        running = false;
        if (simThread != null) {
            simThread.interrupt();
        }
        startButton.setEnabled(true);
        pauseButton.setEnabled(false);
        logMessage("=== SIMULATION STOPPED BY CONTROLLER ===");
    }

    public void forceCongestion() {
        congestionForced = true;
        if (laundromat != null) {
            laundromat.forceCongestion();
        }
    }

    public void resumeService() {
        congestionForced = false;
        if (laundromat != null) {
            laundromat.resumeService();
        }
    }

    public boolean isCongestionForced() {
        return congestionForced;
    }

    private void refreshDisplays() {
        updateWasherDisplay();
        updateDryerDisplay();
        updateKioskDisplay();
        updateFoldingDisplay();
        
        if (stats != null && statsLabel != null && titleStatsLabel != null) {
            int completed = stats.getCustomersCompleted();
            int left = stats.getCustomersLeft();
            int served = completed + left;
            int active = activeCustomers.get();
            int congestion = stats.getCongestionEvents();
            
            statsLabel.setText(String.format("Customers Served: %d | Active: %d | Completed: %d",
                served, active, completed));
            
            titleStatsLabel.setText(String.format("Customers: %d | Completed: %d | Left: %d | Active: %d | Congestion: %d",
                served, completed, left, active, congestion));
        }
    }
    
    private void startRefreshTimer() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(300);
                    refreshDisplays();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();
    }
}