package ccpsmartlaundry;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.*;

public class FoldingStation {
    private Semaphore available;
    private boolean[] stationInUse;
    private final Object lock = new Object();
    private AtomicInteger waitingQueue = new AtomicInteger(0);
    
    public FoldingStation() {
        this.available = new Semaphore(2, true);
        this.stationInUse = new boolean[2];
        Arrays.fill(stationInUse, false);
    }

    public void acquireStation(int customerID) throws InterruptedException {
        waitingQueue.incrementAndGet();
        System.out.printf("[%.2f] Customer-%d waiting for folding station\n",
            CCPSmartLaundry.getCurrentTime(), customerID);
        
        available.acquire();
        waitingQueue.decrementAndGet();
        
        int stationID;
        synchronized (lock) {
            stationID = getAvailableStation();
        }
        
        System.out.printf("[%.2f] Customer-%d acquired folding station %d (%d available)\n",
            CCPSmartLaundry.getCurrentTime(), customerID, stationID, available.availablePermits());
    }
    
    public boolean tryAcquireStation() {
        if (available.tryAcquire()) {
            int stationID;
            synchronized (lock) {
                stationID = getAvailableStation();
            }
            if (stationID != -1) {
                return true;
            } else {
                available.release();
            }
        }
        return false;
    }

    public void releaseStation() {
        int stationID;
        synchronized (lock) {
            stationID = releaseStationAndGetId();
        }
        
        available.release();
        
        System.out.printf("[%.2f] Customer released folding station %d (%d available)\n",
            CCPSmartLaundry.getCurrentTime(), stationID, available.availablePermits());
    }
    
    private int getAvailableStation() {
        for (int i = 0; i < stationInUse.length; i++) {
            if (!stationInUse[i]) {
                stationInUse[i] = true;
                return i;
            }
        }
        return -1;
    }
    
    private int releaseStationAndGetId() {
        for (int i = 0; i < stationInUse.length; i++) {
            if (stationInUse[i]) {
                stationInUse[i] = false;
                return i;
            }
        }
        return -1;
    }
    
    public boolean[] getStationInUse() {
        synchronized (lock) {
            return stationInUse.clone();
        }
    }
    
    public int getWaitingQueue() {
        return waitingQueue.get();
    }
    
    public void incrementWaiting() {
        waitingQueue.incrementAndGet();
    }
    
    public void decrementWaiting() {
        waitingQueue.decrementAndGet();
    }
    
    public int getTotalCount() {
        return 2;
    }
}