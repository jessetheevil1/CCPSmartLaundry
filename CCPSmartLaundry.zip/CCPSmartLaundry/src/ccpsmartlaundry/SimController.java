package ccpsmartlaundry;

public class SimController extends Thread{
    private LaundryPanel panel;
    private int scenario;
    private boolean controllerRunning = false;
    private boolean stopRequested = false;
    private boolean ownerCalled = false;
    
    public SimController(LaundryPanel panel, int scenario) {
        this.panel = panel;
        this.scenario = scenario;
    }
    
    @Override
    public void run() {
        try {
            controllerRunning = true;
            panel.logMessage("=== SIMULATION CONTROLLER STARTED ===");
            
            panel.startSim();
            
            Thread.sleep(1000);
            
            switch(scenario) {
                case CCPSmartLaundry.SCENARIO_NORMAL:
                    runNormalScenario();
                    break;
                    
                case CCPSmartLaundry.SCENARIO_CONGESTED:
                    runCongestedScenario();
                    break;
                    
                default:
                    panel.logMessage("Unknown scenario! Running normal...");
                    runNormalScenario();
                    break;
            }
            
        } catch (InterruptedException e) {
            panel.logMessage("Controller interrupted.");
        } finally {
            controllerRunning = false;
        }
    }
    
    private void runNormalScenario() throws InterruptedException {
        panel.logMessage("=== NORMAL SCENARIO ===");
        panel.logMessage("6 Washers, 4 Dryers, 2 Kiosks, 2 Folding Stations");
        panel.logMessage("10% failure chance for washers and payment kiosks");
        panel.logMessage("Congestion triggers naturally when 30+ customers wait at payment");
        panel.logMessage("Customer patience: 20 seconds");
        panel.logMessage("Wash: 4-6s, Dry: 3-5s, Payment: 1-2s, Fold: 1.5s");
        panel.logMessage("Arrival: 0-0.5s");
        panel.logMessage("Simulation running for 75 seconds");
        
        for (int i = 0; i < 75 && panel.isRunning() && !stopRequested; i++) {
            Thread.sleep(1000);
        }
        
        if (panel.isRunning() && !stopRequested) {
            panel.logMessage("=== SIMULATION COMPLETED ===");
            panel.stopSim();
        }
    }

    private void runCongestedScenario() throws InterruptedException {
        panel.logMessage("=== CONGESTED SCENARIO ===");
        panel.logMessage("Both payment kiosks have FAILED for the day!");
        panel.logMessage("Owner will be called when 30+ customers are waiting.");
        panel.logMessage("Owner will fix the kiosks and service will resume.");
        panel.logMessage("Simulation running for 120 seconds.");
        
        panel.forceCongestion();
        panel.logMessage("[SYSTEM] Both payment kiosks are now BROKEN!");
        panel.logMessage("[SYSTEM] Red congestion indicator should be visible.");
        
        int checkCounter = 0;
        boolean ownerCalled = false;
        int lastLoggedQueue = 0;
        
        while (panel.isRunning() && !stopRequested && checkCounter < 120) {
            Thread.sleep(1000);
            checkCounter++;
            
            int waitingCount = panel.getKioskRef().getWaitingCount();
            
            if (waitingCount >= 30 && !ownerCalled) {
                ownerCalled = true;
                panel.logMessage(String.format("[SYSTEM] %d customers waiting at payment queue!", waitingCount));
                panel.logMessage("[SYSTEM] OWNER HAS BEEN CALLED!");
                panel.logMessage("[SYSTEM] Owner is fixing the kiosks... (5 seconds)");
                
                Thread.sleep(5000);
                
                panel.resumeService();
                panel.logMessage("[SYSTEM] Owner fixed both kiosks! Service resuming.");
                panel.logMessage("[SYSTEM] Remaining customers can now complete payment.");
                
                for (int i = 0; i < 10 && panel.isRunning() && !stopRequested; i++) {
                    Thread.sleep(1000);
                }
                
                if (panel.isRunning() && !stopRequested) {
                    panel.logMessage("=== SIMULATION COMPLETED ===");
                    panel.stopSim();
                }
                return;
            }
            
            if (waitingCount != lastLoggedQueue && waitingCount > 0 && !ownerCalled) {
                panel.logMessage(String.format("[SYSTEM] Payment queue: %d customers waiting...", waitingCount));
                lastLoggedQueue = waitingCount;
            }
            
            if (checkCounter % 15 == 0 && !ownerCalled) {
                int completed = panel.getStats().getCustomersCompleted();
                int left = panel.getStats().getCustomersLeft();
                panel.logMessage(String.format("[SYSTEM] Status: %d completed, %d left, %d in payment queue", 
                    completed, left, waitingCount));
            }
        }
        
        if (panel.isRunning() && !stopRequested) {
            if (!ownerCalled) {
                panel.logMessage("[SYSTEM] Simulation ended - queue never reached 30 customers.");
                panel.logMessage("[SYSTEM] Try increasing arrival rate or reducing wash/dry times.");
                panel.resumeService();
            }
            panel.logMessage("=== SIMULATION COMPLETED ===");
            panel.stopSim();
        }
    }
    
    public void stopController() {
        stopRequested = true;
        this.interrupt();
    }
    
    public boolean isControllerRunning() {
        return controllerRunning;
    }
    
    public void setScenario(int scenario) {
        this.scenario = scenario;
    }
}