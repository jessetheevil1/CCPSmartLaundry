package ccpsmartlaundry;

public class Laundromat {
    private Washer washer;
    private Dryer dryer;
    private PaymentKiosk paymentKiosk;
    private FoldingStation foldingStation;
    private Stats stats;
    
    public Laundromat(Stats stats, LaundryPanel panel) {
        this.stats = stats;
        this.washer = new Washer(stats);
        this.dryer = new Dryer(stats);
        this.paymentKiosk = new PaymentKiosk(panel);
        this.foldingStation = new FoldingStation();
        if (panel != null) {
            panel.setResources(washer, dryer, paymentKiosk, foldingStation);
        }
    }
    
    public int acquireWasher(int customerID) throws InterruptedException {
        return washer.acquireWasher(customerID);
    }
    
    public void releaseWasher(int washerID) {
        washer.releaseWasher(washerID);
    }
    
    public int acquireDryer(int customerID) throws InterruptedException {
        return dryer.acquireDryer(customerID);
    }
    
    public void releaseDryer(int dryerID) {
        dryer.releaseDryer(dryerID);
    }
    
    public int acquirePaymentKiosk(int customerID) throws InterruptedException {
        return paymentKiosk.acquireKiosk(customerID);
    }
    
    public void releasePaymentKiosk(int kioskID) {
        paymentKiosk.releaseKiosk(kioskID);
    }
    
    public void acquireFoldingStation(int customerID) throws InterruptedException {
        foldingStation.acquireStation(customerID);
    }
    
    public void releaseFoldingStation() {
        foldingStation.releaseStation();
    }
    
    public int tryAcquireWasher() {
        return washer.tryAcquireWasher();
    }
    
    public int tryAcquireDryer() {
        return dryer.tryAcquireDryer();
    }
    
    public int tryAcquirePaymentKiosk() {
        return paymentKiosk.tryAcquireKiosk();
    }
    
    public boolean tryAcquireFoldingStation() {
        return foldingStation.tryAcquireStation();
    }
    
    public void incrementWasherWaiting() {
        washer.incrementWaiting();
    }
    
    public void decrementWasherWaiting() {
        washer.decrementWaiting();
    }
    
    public void incrementDryerWaiting() {
        dryer.incrementWaiting();
    }
    
    public void decrementDryerWaiting() {
        dryer.decrementWaiting();
    }
    
    public void incrementKioskWaiting() {
        paymentKiosk.incrementWaiting();
    }
    
    public void decrementKioskWaiting() {
        paymentKiosk.decrementWaiting();
    }
    
    public void incrementFoldingWaiting() {
        foldingStation.incrementWaiting();
    }
    
    public void decrementFoldingWaiting() {
        foldingStation.decrementWaiting();
    }
    
    public Washer getWasher() {
        return washer;
    }
    
    public Dryer getDryer() {
        return dryer;
    }
    
    public PaymentKiosk getPaymentKiosk() {
        return paymentKiosk;
    }
    
    public FoldingStation getFoldingStation() {
        return foldingStation;
    }
    
    public void forceCongestion() {
        if (paymentKiosk != null) {
            paymentKiosk.forceCongestion();
        }
    }

    public void resumeService() {
        if (paymentKiosk != null) {
            paymentKiosk.resumeService();
        }
    }
}