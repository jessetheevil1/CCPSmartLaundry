package ccpsmartlaundry;
import java.util.*;

public class Customer implements Runnable {
    private int customerID;
    private Laundromat laundromat;
    private Stats stats;
    private Random random;
    private long arrivalTime;
    private LaundryPanel panel;
    private long waitingStartTime;
    private volatile boolean shouldStop = false;
    private static final long MAX_WAITING_TIME = 20000;
    
    public Customer(int customerID, Laundromat laundromat, Stats stats, LaundryPanel panel) {
        this.customerID = customerID;
        this.laundromat = laundromat;
        this.stats = stats;
        this.random = new Random();
        this.arrivalTime = System.currentTimeMillis();
        this.panel = panel;
        this.waitingStartTime = arrivalTime;
    }
    
    private boolean checkPatience() {
        long waitTime = System.currentTimeMillis() - waitingStartTime;
        if (waitTime > MAX_WAITING_TIME) {
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d gave up waiting after %.1f seconds (impatient)",
                    CCPSmartLaundry.getCurrentTime(), customerID, waitTime / 1000.0));
                panel.updateCustomerCount(Thread.activeCount());
            }
            stats.customerLeft();
            shouldStop = true;
            return false;
        }
        return true;
    }
    
    private int acquireKioskWithPatience() throws InterruptedException {
        waitingStartTime = System.currentTimeMillis();
        laundromat.incrementKioskWaiting();
        try {
            while (!shouldStop) {
                if (!checkPatience()) {
                    return -1;
                }
                int kioskID = laundromat.tryAcquirePaymentKiosk();
                if (kioskID != -1) {
                    if (panel != null) {
                        panel.logMessage(String.format("[%.2f] Customer-%d acquired PaymentKiosk-%d",
                            CCPSmartLaundry.getCurrentTime(), customerID, kioskID));
                    }
                    return kioskID;
                }
                Thread.sleep(500);
            }
        } finally {
            laundromat.decrementKioskWaiting();
        }
        return -1;
    }
    
    private int acquireWasherWithPatience() throws InterruptedException {
        waitingStartTime = System.currentTimeMillis();
        laundromat.incrementWasherWaiting();
        try {
            while (!shouldStop) {
                if (!checkPatience()) {
                    return -1;
                }
                int washerID = laundromat.tryAcquireWasher();
                if (washerID != -1) {
                    if (panel != null) {
                        panel.logMessage(String.format("[%.2f] Customer-%d acquired Washer-%d",
                            CCPSmartLaundry.getCurrentTime(), customerID, washerID));
                    }
                    return washerID;
                }
                Thread.sleep(500);
            }
        } finally {
            laundromat.decrementWasherWaiting();
        }
        return -1;
    }
    
    private int acquireDryerWithPatience() throws InterruptedException {
        waitingStartTime = System.currentTimeMillis();
        laundromat.incrementDryerWaiting();
        try {
            while (!shouldStop) {
                if (!checkPatience()) {
                    return -1;
                }
                int dryerID = laundromat.tryAcquireDryer();
                if (dryerID != -1) {
                    if (panel != null) {
                        panel.logMessage(String.format("[%.2f] Customer-%d acquired Dryer-%d",
                            CCPSmartLaundry.getCurrentTime(), customerID, dryerID));
                    }
                    return dryerID;
                }
                Thread.sleep(500);
            }
        } finally {
            laundromat.decrementDryerWaiting();
        }
        return -1;
    }
    
    private boolean acquireFoldingWithPatience() throws InterruptedException {
        waitingStartTime = System.currentTimeMillis();
        laundromat.incrementFoldingWaiting();
        try {
            while (!shouldStop) {
                if (!checkPatience()) {
                    return false;
                }
                if (laundromat.tryAcquireFoldingStation()) {
                    if (panel != null) {
                        panel.logMessage(String.format("[%.2f] Customer-%d acquired Folding Station",
                            CCPSmartLaundry.getCurrentTime(), customerID));
                    }
                    return true;
                }
                Thread.sleep(500);
            }
        } finally {
            laundromat.decrementFoldingWaiting();
        }
        return false;
    }
    
    @Override
    public void run() {
        if (panel != null) {
            panel.logMessage(String.format("[%.2f] Customer-%d arrived at the laundry",
                CCPSmartLaundry.getCurrentTime(), customerID));
            panel.updateCustomerCount(Thread.activeCount());
        }
        
        try {
            int kioskID = acquireKioskWithPatience();
            if (shouldStop || kioskID == -1) {
                cleanupAndExit();
                return;
            }
            
            int payTime = 1000 + random.nextInt(1001);
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d started PAYMENT at Kiosk-%d (%d seconds)",
                    CCPSmartLaundry.getCurrentTime(), customerID, kioskID, payTime / 1000));
            }
            Thread.sleep(payTime);
            
            if (random.nextDouble() < 0.10) {
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] PAYMENT KIOSK-%d FAILED for Customer-%d ! Retrying...",
                        CCPSmartLaundry.getCurrentTime(), kioskID, customerID));
                }
                laundromat.releasePaymentKiosk(kioskID);
                Thread.sleep(2000);
                
                kioskID = acquireKioskWithPatience();
                if (shouldStop || kioskID == -1) {
                    cleanupAndExit();
                    return;
                }
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] Customer-%d retrying PAYMENT at Kiosk-%d",
                        CCPSmartLaundry.getCurrentTime(), customerID, kioskID));
                }
                Thread.sleep(1000 + random.nextInt(1001));
            }
            
            laundromat.releasePaymentKiosk(kioskID);
            
            int washerID = acquireWasherWithPatience();
            if (shouldStop || washerID == -1) {
                cleanupAndExit();
                return;
            }
            
            int washTime = 4000 + random.nextInt(2001);
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d started WASHING on Washer-%d (%d seconds)",
                    CCPSmartLaundry.getCurrentTime(), customerID, washerID, washTime / 1000));
            }
            Thread.sleep(washTime);
            
            if (random.nextDouble() < 0.10) {
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] WASHER-%d FAILED for Customer-%d ! Retrying...",
                        CCPSmartLaundry.getCurrentTime(), washerID, customerID));
                }
                laundromat.releaseWasher(washerID);
                
                washerID = acquireWasherWithPatience();
                if (shouldStop || washerID == -1) {
                    cleanupAndExit();
                    return;
                }
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] Customer-%d retrying WASHING on Washer-%d",
                        CCPSmartLaundry.getCurrentTime(), customerID, washerID));
                }
                Thread.sleep(4000 + random.nextInt(2001));
            }
            
            laundromat.releaseWasher(washerID);
            
            int dryerID = acquireDryerWithPatience();
            if (shouldStop || dryerID == -1) {
                cleanupAndExit();
                return;
            }
            
            int dryTime = 3000 + random.nextInt(2001);
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d started DRYING on Dryer-%d (%d seconds)",
                    CCPSmartLaundry.getCurrentTime(), customerID, dryerID, dryTime / 1000));
            }
            Thread.sleep(dryTime);
            laundromat.releaseDryer(dryerID);
            
            if (!acquireFoldingWithPatience()) {
                cleanupAndExit();
                return;
            }
            
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d started FOLDING clothes",
                    CCPSmartLaundry.getCurrentTime(), customerID));
            }
            Thread.sleep(1500);
            laundromat.releaseFoldingStation();
            
            long totalTime = System.currentTimeMillis() - arrivalTime;
            stats.customerCompleted(totalTime);
            
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d COMPLETED! Total time: %.2f seconds",
                    CCPSmartLaundry.getCurrentTime(), customerID, totalTime / 1000.0));
                panel.updateCustomerCount(Thread.activeCount());
            }
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (panel != null) {
                panel.logMessage(String.format("[%.2f] Customer-%d was interrupted",
                    CCPSmartLaundry.getCurrentTime(), customerID));
            }
            cleanupAndExit();
        }
    }
    
    private void cleanupAndExit() {
        if (panel != null) {
            panel.updateCustomerCount(Thread.activeCount());
        }
    }
}