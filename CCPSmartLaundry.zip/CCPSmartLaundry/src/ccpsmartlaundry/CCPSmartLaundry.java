package ccpsmartlaundry;
import java.applet.*;
import java.awt.*;
import javax.swing.*;

public class CCPSmartLaundry extends Applet {
    
    public static long SIM_START_TIME;
    private LaundryPanel laundryPanel;
    
    public static final int SCENARIO_NORMAL = 0;
    public static final int SCENARIO_CONGESTED = 1;
    private static int selectedScenario;

    @Override
    public void init() {
        setLayout(new BorderLayout());
        setBackground(Color.lightGray);
        
        laundryPanel = new LaundryPanel();
        add(laundryPanel, BorderLayout.CENTER);
    }

    @Override
    public void start() {
    }
    
    @Override
    public void stop() {
    }
    
    @Override
    public void destroy() {
        super.destroy();
    }

    public static double getCurrentTime() {
        return (System.currentTimeMillis() - SIM_START_TIME) / 1000.0;
    }
    
    public static int getSelectedScenario() {
        return selectedScenario;
    }

    
    public static void main(String[] args) {
        selectedScenario = 0;  
        
        JFrame frame = new JFrame("CCP Smart Laundry Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1300, 900);
        frame.setLayout(new BorderLayout());
        
        CCPSmartLaundry applet = new CCPSmartLaundry();
        applet.init();
        applet.start();
        
        frame.add(applet, BorderLayout.CENTER);
        
        frame.setLocationRelativeTo(null);
        
        frame.setVisible(true);
    }
}