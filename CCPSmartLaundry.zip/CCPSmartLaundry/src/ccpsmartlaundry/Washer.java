package ccpsmartlaundry;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.*;

public class Washer {
    private Semaphore available;
    private boolean washerInUse[];
    private Stats stats;
    private final Object lock = new Object();
    private AtomicInteger waitingQueue = new AtomicInteger(0);
    
    public Washer(Stats stats) {
        this.stats = stats;
        this.available = new Semaphore(6, true);
        this.washerInUse = new boolean[6];
        Arrays.fill(washerInUse, false);
    }

    public int acquireWasher(int customerID) throws InterruptedException {
        waitingQueue.incrementAndGet();
        System.out.printf("[%.2f] Customer-%d waiting for washing machine\n",
            CCPSmartLaundry.getCurrentTime(), customerID);
        
        available.acquire();
        waitingQueue.decrementAndGet();
        
        int washerID;
        synchronized (lock) {
            washerID = getAvailableWasher();
        }
        
        int inUse = 6 - available.availablePermits();
        stats.updateWasherUsage(inUse);
        
        System.out.printf("[%.2f] Customer-%d acquired Washer-%d (%d washers available)\n",
            CCPSmartLaundry.getCurrentTime(), customerID, washerID, available.availablePermits());
        
        return washerID;
    }
    
    public int tryAcquireWasher() {
        if (available.tryAcquire()) {
            int washerID;
            synchronized (lock) {
                washerID = getAvailableWasher();
            }
            if (washerID != -1) {
                int inUse = 6 - available.availablePermits();
                stats.updateWasherUsage(inUse);
                return washerID;
            } else {
                available.release();
            }
        }
        return -1;
    }

    public void releaseWasher(int washerID) {
        synchronized (lock) {
            washerInUse[washerID] = false;
        }
        
        available.release();
        
        int inUse = 6 - available.availablePermits();
        stats.updateWasherUsage(inUse);
        
        System.out.printf("[%.2f] Customer released Washer-%d (%d washers available)\n",
            CCPSmartLaundry.getCurrentTime(), washerID, available.availablePermits());
    }

    private int getAvailableWasher() {
        for (int i = 0; i < washerInUse.length; i++) {
            if (!washerInUse[i]) {
                washerInUse[i] = true;
                return i;
            }
        }
        return -1;
    }
    
    public boolean[] getWasherInUse() {
        synchronized (lock) {
            return washerInUse.clone();
        }
    }
    
    public int getWaitingQueue() {
        return waitingQueue.get();
    }
    
    public void incrementWaiting() {
        waitingQueue.incrementAndGet();
    }
    
    public void decrementWaiting() {
        waitingQueue.decrementAndGet();
    }
    
    public int getTotalCount() {
        return 6;
    }
}