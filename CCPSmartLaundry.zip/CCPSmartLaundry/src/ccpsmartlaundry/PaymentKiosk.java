package ccpsmartlaundry;
import java.util.concurrent.locks.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class PaymentKiosk {
    private ReentrantLock reLock;
    private Condition available;
    private boolean[] kioskInUse;
    private int waitingCount;
    private LaundryPanel panel;
    private boolean congestedMode;
    private int congestionThreshold = 30;
    private ReentrantLock congestionLock;
    private AtomicInteger congestionEventCount;
    private boolean naturalCongestionEnabled = true;
    private Random random = new Random();
    
    public PaymentKiosk(LaundryPanel panel) {
        this.panel = panel;
        this.reLock = new ReentrantLock(true);
        this.available = reLock.newCondition();
        this.kioskInUse = new boolean[2];
        Arrays.fill(kioskInUse, false);
        this.waitingCount = 0;
        this.congestedMode = false;
        this.congestionLock = new ReentrantLock();
        this.congestionEventCount = new AtomicInteger(0);
    }
    
    public void setNaturalCongestionEnabled(boolean enabled) {
        this.naturalCongestionEnabled = enabled;
    }
    
    public boolean isCongestedMode() {
        reLock.lock();
        try {
            return congestedMode;
        } finally {
            reLock.unlock();
        }
    }
    
    public void forceCongestion() {
        reLock.lock();
        try {
            if (!congestedMode) {
                congestedMode = true;
                congestionEventCount.incrementAndGet();

                if (panel != null && panel.getStats() != null) {
                    panel.getStats().congestionEventOccurred();
                }

                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] !!! CONGESTION ACTIVATED !!! Both kiosks FAILED !!!",
                        CCPSmartLaundry.getCurrentTime()));
                    panel.showCongestionAlert(true);
                    panel.showCongestionIndicator(true);
                }

                for (int i = 0; i < kioskInUse.length; i++) {
                    kioskInUse[i] = true;
                }
                
                naturalCongestionEnabled = false;
            }
        } finally {
            reLock.unlock();
        }
    }

    public void resumeService() {
        reLock.lock();
        try {
            if (congestedMode) {
                for (int i = 0; i < kioskInUse.length; i++) {
                    kioskInUse[i] = false;
                }
                available.signalAll();
                congestedMode = false;

                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] Service resumed. Kiosks are available.",
                        CCPSmartLaundry.getCurrentTime()));
                    panel.showCongestionAlert(false);
                    panel.showCongestionIndicator(false);
                }
            }
        } finally {
            reLock.unlock();
        }
    }
    
    public int getCongestionEventCount() {
        return congestionEventCount.get();
    }

    public int getWaitingQueue() {
        return waitingCount;
    }

    public int acquireKiosk(int customerID) throws InterruptedException {
        reLock.lock();
        try {
            waitingCount++;
            
            if (naturalCongestionEnabled && !congestedMode && waitingCount >= congestionThreshold) {
                if (congestionLock.tryLock()) {
                    try {
                        if (naturalCongestionEnabled && !congestedMode && waitingCount >= congestionThreshold) {
                            congestedMode = true;
                            congestionEventCount.incrementAndGet();
                            
                            if (panel != null && panel.getStats() != null) {
                                panel.getStats().congestionEventOccurred();
                            }

                            System.out.printf("[%.2f] !!! CONGESTION! %d customers waiting! Both payment kiosks FAILED !!!\n",
                                CCPSmartLaundry.getCurrentTime(), waitingCount);

                            for (int i = 0; i < kioskInUse.length; i++) {
                                kioskInUse[i] = true;
                            }
                            
                            if (panel != null) {
                                panel.logMessage(String.format("[%.2f] !!! CONGESTION! %d customers waiting! Both kiosks FAILED !!!",
                                    CCPSmartLaundry.getCurrentTime(), waitingCount));
                                panel.showCongestionAlert(true);
                                panel.showCongestionIndicator(true);
                                panel.logMessage(String.format("[%.2f] Owner called! Fixing kiosks... (5 seconds)",
                                    CCPSmartLaundry.getCurrentTime()));
                            }
                            
                            Thread.sleep(5000);
                            
                            for (int i = 0; i < kioskInUse.length; i++) {
                                kioskInUse[i] = false;
                            }
                            available.signalAll();
                            
                            congestedMode = false;
                            
                            if (panel != null) {
                                panel.logMessage(String.format("[%.2f] Owner fixed both kiosks! Service resuming.",
                                    CCPSmartLaundry.getCurrentTime()));
                                panel.showCongestionAlert(false);
                                panel.showCongestionIndicator(false);
                            }
                        }
                    } finally {
                        congestionLock.unlock();
                    }
                }
            }
            
            if (panel != null && waitingCount > 0) {
                panel.logMessage(String.format("[%.2f] Customer-%d waiting for payment (queue: %d)%s",
                    CCPSmartLaundry.getCurrentTime(), customerID, waitingCount,
                    congestedMode ? " [CONGESTION ACTIVE]" : ""));
            }
            
            System.out.printf("[%.2f] Customer-%d waiting for payment kiosk (queue: %d)\n",
                CCPSmartLaundry.getCurrentTime(), customerID, waitingCount);
            
            while (true) {
                int kioskID = getAvailableKiosk();
                if (kioskID != -1) {
                    waitingCount--;
                    if (panel != null) {
                        panel.logMessage(String.format("[%.2f] Customer-%d acquired PaymentKiosk-%d",
                            CCPSmartLaundry.getCurrentTime(), customerID, kioskID));
                    }
                    System.out.printf("[%.2f] Customer-%d acquired PaymentKiosk-%d\n",
                        CCPSmartLaundry.getCurrentTime(), customerID, kioskID);
                    return kioskID;
                }
                available.await(500, TimeUnit.MILLISECONDS);
            }
        } catch (InterruptedException e) {
            if (reLock.isHeldByCurrentThread()) {
                waitingCount--;
            }
            throw e;
        } finally {
            reLock.unlock();
        }
    }
    
    public int tryAcquireKiosk() {
        reLock.lock();
        try {
            if (congestedMode) {
                return -1;
            }
            
            int kioskID = getAvailableKiosk();
            if (kioskID != -1) {
                waitingCount--;
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] Customer acquired PaymentKiosk-%d (queue: %d)",
                        CCPSmartLaundry.getCurrentTime(), kioskID, waitingCount));
                }
                return kioskID;
            }
            return -1;
        } finally {
            reLock.unlock();
        }
    }

    public void releaseKiosk(int kioskID) {
        reLock.lock();
        try {
            if (kioskID >= 0 && kioskID < kioskInUse.length) {
                kioskInUse[kioskID] = false;
                if (panel != null) {
                    panel.logMessage(String.format("[%.2f] Customer released PaymentKiosk-%d",
                        CCPSmartLaundry.getCurrentTime(), kioskID));
                }
                System.out.printf("[%.2f] Customer released PaymentKiosk-%d\n",
                    CCPSmartLaundry.getCurrentTime(), kioskID);
                available.signal();
            }
        } finally {
            reLock.unlock();
        }
    }
    
    private int getAvailableKiosk() {
        if (congestedMode) return -1;
        
        for (int i = 0; i < kioskInUse.length; i++) {
            if (!kioskInUse[i]) {
                kioskInUse[i] = true;
                return i;
            }
        }
        return -1;
    }
    
    public boolean[] getKioskInUse() {
        reLock.lock();
        try {
            return kioskInUse.clone();
        } finally {
            reLock.unlock();
        }
    }
    
    public int getWaitingCount() {
        reLock.lock();
        try {
            return waitingCount;
        } finally {
            reLock.unlock();
        }
    }
    
    public void incrementWaiting() {
        reLock.lock();
        try {
            waitingCount++;
        } finally {
            reLock.unlock();
        }
    }
    
    public void decrementWaiting() {
        reLock.lock();
        try {
            waitingCount--;
            if (waitingCount < 0) waitingCount = 0;
        } finally {
            reLock.unlock();
        }
    }
    
    public int getTotalCount() {
        return 2;
    }
}