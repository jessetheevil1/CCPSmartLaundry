package ccpsmartlaundry;
import java.util.concurrent.atomic.*;

public class Stats {
    private AtomicInteger customersCompleted = new AtomicInteger(0);
    private AtomicInteger customersLeft = new AtomicInteger(0);
    private AtomicLong totalServiceTime = new AtomicLong(0);
    private AtomicInteger maxConcurrentWashers = new AtomicInteger(0);
    private AtomicInteger maxConcurrentDryers = new AtomicInteger(0);
    private AtomicInteger congestionEvents = new AtomicInteger(0);
    private AtomicInteger congestionDeadlocksResolved = new AtomicInteger(0);

    
    private int currentWashers = 0;
    private int currentDryers = 0;
    
    public synchronized void customerCompleted(long serviceTimeMs) {
        customersCompleted.incrementAndGet();
        totalServiceTime.addAndGet(serviceTimeMs);
    }
    
    public synchronized void customerLeft() {
        customersLeft.incrementAndGet();
    }
    
    public synchronized void updateWasherUsage(int currentInUse) {
        currentWashers = currentInUse;
        if (currentInUse > maxConcurrentWashers.get()) {
            maxConcurrentWashers.set(currentInUse);
        }
    }
    
    public synchronized void updateDryerUsage(int currentInUse) {
        currentDryers = currentInUse;
        if (currentInUse > maxConcurrentDryers.get()) {
            maxConcurrentDryers.set(currentInUse);
        }
    }
    
    public synchronized void congestionEventOccurred() {
        congestionEvents.incrementAndGet();
    }

    public synchronized void congestionDeadlockResolved() {
        congestionDeadlocksResolved.incrementAndGet();
    }

    public synchronized int getCongestionEvents() {
        return congestionEvents.get();
    }

    public synchronized int getCongestionDeadlocksResolved() {
        return congestionDeadlocksResolved.get();
    }
    
    public synchronized int getCustomersCompleted() {
        return customersCompleted.get();
    }
    
    public synchronized int getCustomersLeft() {
        return customersLeft.get();
    }
    
    public synchronized int getTotalCustomers() {
        return customersCompleted.get() + customersLeft.get();
    }
    
    public synchronized void printReport() {
        int completed = customersCompleted.get();
        int left = customersLeft.get();
        long totalTime = totalServiceTime.get();

        System.out.println("");
        System.out.println("==================================================");
        System.out.println("SIMULATION STATISTICS");
        System.out.println("==================================================");
        System.out.println("Customers completed: " + completed);
        System.out.println("Customers left (impatient): " + left);
        System.out.println("Total customers arrived: " + (completed + left));

        if (completed > 0) {
            double avgTime = totalTime / (double) completed / 1000.0;
            System.out.printf("Average total time per completed customer: %.2f seconds\n", avgTime);
        }

        System.out.println("Maximum concurrent washers in use: " + maxConcurrentWashers.get());
        System.out.println("Maximum concurrent dryers in use: " + maxConcurrentDryers.get());
        System.out.println("-----------------------------------------------");
        System.out.println("CONGESTION STATISTICS:");
        System.out.println("  Congestion events: " + congestionEvents.get());
        System.out.println("  Congestion deadlocks resolved: " + congestionDeadlocksResolved.get());
        System.out.println("==================================================");
    }
}